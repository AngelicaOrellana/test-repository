Ruby Basics
=================

The goal of this multi-part assignment is to get you accustomed to basic
Ruby coding and introduce you to RSpec, the unit testing tool we will be
using heavily.